;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x-org-lint" "20260302.947"
  "Run org-lint on Org files."
  '((emacs     "26.1")
    (commander "0.7.0")
    (ansi      "0.4.1"))
  :url "https://github.com/emacs-eine/x-org-lint"
  :commit "4fc94b2f20defea99236ab51cff693a4fdce73d6"
  :revdesc "4fc94b2f20de"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
